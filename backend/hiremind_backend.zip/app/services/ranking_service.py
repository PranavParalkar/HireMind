"""Candidate Ranking Service."""
from typing import Dict, List

from app.services.scoring_service import ScoringService
from app.utils.logger import logger


class RankingService:

    def __init__(self):
        self.scoring = ScoringService()

    def rank(self, resumes: List[Dict], job_description: str) -> List[Dict]:
        if not resumes:
            return []
        if not job_description or not job_description.strip():
            raise ValueError("Job description must not be empty.")

        logger.info(f"Ranking {len(resumes)} candidates")
        ranked: List[Dict] = []

        for idx, resume in enumerate(resumes):
            try:
                score = self.scoring.score(resume, job_description)
                ranked.append({
                    "candidate_id": resume.get("id") or resume.get("filename") or f"candidate_{idx}",
                    "name": resume.get("name"),
                    "email": resume.get("email"),
                    **score,
                })
            except Exception as exc:
                logger.exception(f"Failed to score candidate #{idx}: {exc}")
                ranked.append({
                    "candidate_id": resume.get("id") or resume.get("filename") or f"candidate_{idx}",
                    "name": resume.get("name"),
                    "error": str(exc),
                    "fit_score": 0.0,
                    "recommendation": "Reject",
                })

        ranked.sort(key=lambda r: r.get("fit_score", 0.0), reverse=True)
        for i, c in enumerate(ranked, start=1):
            c["rank"] = i
        return ranked
