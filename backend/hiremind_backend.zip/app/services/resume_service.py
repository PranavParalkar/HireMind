"""Resume Intelligence Engine — parses PDF/DOCX and extracts structured fields."""
import re
from datetime import datetime
from typing import Dict, List, Optional

from app.services.nlp_engine import get_nlp_engine
from app.utils.file_parser import extract_text
from app.utils.logger import logger
from app.utils.skills_db import SKILLS_VOCAB, canonical

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(\+?\d[\d\s().\-]{7,}\d)")
YEARS_RE = re.compile(
    r"(\d{1,2})\+?\s*(?:years?|yrs?)\s*(?:of)?\s*(?:experience|exp)?",
    re.IGNORECASE,
)
DATE_RANGE_RE = re.compile(
    r"(?P<start>\b(?:19|20)\d{2})\s*[-\u2013to]+\s*(?P<end>(?:19|20)\d{2}|present|current)",
    re.IGNORECASE,
)
EDUCATION_KW_RE = re.compile(
    r"(?<![A-Za-z0-9])(?:bachelor|b\.tech|btech|b\.e\.|bsc|b\.sc|"
    r"master|m\.tech|mtech|m\.e\.|msc|m\.sc|mba|phd|doctorate|diploma|associate)(?![A-Za-z0-9])",
    re.IGNORECASE,
)


class ResumeService:

    def __init__(self):
        self.nlp = get_nlp_engine().get_spacy()

    def parse(self, filename: str, file_bytes: bytes) -> Dict:
        logger.info(f"Parsing resume: {filename}")
        raw_text = extract_text(filename, file_bytes)
        if not raw_text:
            raise ValueError("No text could be extracted from the resume.")
        cleaned = self._clean_text(raw_text)
        result = {
            "filename": filename,
            "name": self._extract_name(cleaned),
            "email": self._extract_email(cleaned),
            "phone": self._extract_phone(cleaned),
            "skills": self._extract_skills(cleaned),
            "experience_years": self._extract_experience_years(cleaned),
            "education": self._extract_education(cleaned),
            "raw_text": cleaned,
        }
        logger.info(
            f"Parsed '{filename}': {len(result['skills'])} skills, "
            f"{result['experience_years']} yrs exp"
        )
        return result

    @staticmethod
    def _clean_text(text: str) -> str:
        text = text.replace("\r", "\n")
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{2,}", "\n\n", text)
        return text.strip()

    def _extract_name(self, text: str) -> Optional[str]:
        try:
            doc = self.nlp(text[:500])
            for ent in doc.ents:
                if ent.label_ == "PERSON":
                    return ent.text.strip()
        except Exception:
            pass
        for line in text.splitlines():
            line = line.strip()
            if (line and len(line.split()) <= 5 and not EMAIL_RE.search(line)
                    and not PHONE_RE.search(line) and line[0].isalpha()):
                return line
        return None

    @staticmethod
    def _extract_email(text: str) -> Optional[str]:
        m = EMAIL_RE.search(text)
        return m.group(0) if m else None

    @staticmethod
    def _extract_phone(text: str) -> Optional[str]:
        m = PHONE_RE.search(text)
        if not m:
            return None
        phone = re.sub(r"[^\d+]", "", m.group(0))
        return phone if len(phone) >= 8 else None

    @staticmethod
    def _extract_skills(text: str) -> List[str]:
        found = set()
        lower = text.lower()
        for skill in SKILLS_VOCAB:
            escaped = re.escape(skill)
            if any(c in skill for c in ".+#"):
                pattern = r"(?<![A-Za-z0-9+#.])" + escaped + r"(?![A-Za-z0-9+#.])"
            else:
                pattern = r"\b" + escaped + r"\b"
            if re.search(pattern, lower):
                found.add(canonical(skill))
        return sorted(found)

    @staticmethod
    def _extract_experience_years(text: str) -> float:
        explicit = [int(m.group(1)) for m in YEARS_RE.finditer(text)]
        if explicit:
            return float(max(explicit))
        current_year = datetime.now().year
        total = 0
        for m in DATE_RANGE_RE.finditer(text):
            try:
                start = int(m.group("start"))
                end_raw = m.group("end").lower()
                end = current_year if end_raw in ("present", "current") else int(end_raw)
                if end >= start:
                    total += end - start
            except ValueError:
                continue
        return float(total)

    @staticmethod
    def _extract_education(text: str) -> List[str]:
        found, seen = [], set()
        for line in text.splitlines():
            line = line.strip()
            if line and line not in seen and EDUCATION_KW_RE.search(line):
                found.append(line)
                seen.add(line)
        return found[:10]
