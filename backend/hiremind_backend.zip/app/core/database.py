"""Database connection and session management (SQLAlchemy).

Engine is created lazily so importing this module never crashes even if
psycopg2 is not installed or the database is not yet running.
"""
from typing import Optional

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.core.config import settings
from app.utils.logger import logger

Base = declarative_base()
_engine: Optional[Engine] = None
_SessionLocal = None


def get_engine() -> Engine:
    global _engine, _SessionLocal
    if _engine is None:
        _engine = create_engine(
            settings.DATABASE_URL,
            pool_pre_ping=True,
            pool_size=10,
            max_overflow=20,
        )
        _SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=_engine)
    return _engine


def get_session_factory():
    if _SessionLocal is None:
        get_engine()
    return _SessionLocal


def get_db():
    """FastAPI dependency — yields a DB session, closes after request."""
    SessionLocal = get_session_factory()
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Create all tables. Use Alembic migrations in production."""
    from app.models import models  # noqa: F401
    try:
        Base.metadata.create_all(bind=get_engine())
    except Exception as exc:
        logger.warning(f"DB init skipped ({exc.__class__.__name__}): {exc}")
