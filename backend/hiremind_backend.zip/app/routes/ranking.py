"""Ranking endpoint."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from app.schemas.scoring import RankCandidatesRequest, RankCandidatesResponse, RankedCandidate
from app.services.ranking_service import RankingService
from app.utils.logger import logger

router = APIRouter(prefix="/ranking", tags=["Ranking"])
_ranking_service: Optional[RankingService] = None


def get_ranking_service() -> RankingService:
    global _ranking_service
    if _ranking_service is None:
        _ranking_service = RankingService()
    return _ranking_service


@router.post("/rank-candidates", response_model=RankCandidatesResponse,
             summary="Rank candidates by fit score for a single JD")
async def rank_candidates(
    payload: RankCandidatesRequest,
    service: RankingService = Depends(get_ranking_service),
):
    if not payload.resumes:
        raise HTTPException(status_code=422, detail="At least one resume is required.")
    try:
        ranked = service.rank([r.model_dump() for r in payload.resumes], payload.job_description)
        return RankCandidatesResponse(
            success=True, total=len(ranked),
            job_description_preview=payload.job_description[:200],
            results=[RankedCandidate(**item) for item in ranked],
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error in rank_candidates")
        raise HTTPException(status_code=500, detail=f"Ranking failed: {exc}")
