"""Resume upload + parsing endpoint."""
from typing import Optional
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_session_factory
from app.schemas.resume import ParsedResume, ResumeUploadResponse
from app.services.resume_service import ResumeService
from app.utils.file_parser import UnsupportedFileError
from app.utils.logger import logger

router = APIRouter(prefix="/resumes", tags=["Resumes"])
_resume_service: Optional[ResumeService] = None


def get_resume_service() -> ResumeService:
    global _resume_service
    if _resume_service is None:
        _resume_service = ResumeService()
    return _resume_service


def get_db_optional():
    try:
        SessionLocal = get_session_factory()
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()
    except Exception as exc:
        logger.warning(f"DB unavailable: {exc}")
        yield None


@router.post("/upload-resume", response_model=ResumeUploadResponse,
             summary="Upload a resume (PDF/DOCX) and receive parsed JSON")
async def upload_resume(
    file: UploadFile = File(...),
    db: Optional[Session] = Depends(get_db_optional),
    service: ResumeService = Depends(get_resume_service),
):
    if not file.filename:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No filename provided.")

    if not file.filename.lower().endswith((".pdf", ".docx")):
        raise HTTPException(status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                            detail="Only .pdf and .docx files are supported.")

    contents = await file.read()
    if len(contents) / (1024 * 1024) > settings.MAX_FILE_SIZE_MB:
        raise HTTPException(status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                            detail=f"File too large. Max {settings.MAX_FILE_SIZE_MB} MB.")

    try:
        parsed = service.parse(file.filename, contents)
    except UnsupportedFileError as exc:
        raise HTTPException(status_code=415, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error parsing resume")
        raise HTTPException(status_code=500, detail=f"Failed to parse resume: {exc}")

    if db is not None:
        try:
            from app.models.models import Resume
            db_obj = Resume(
                filename=parsed["filename"], name=parsed.get("name"),
                email=parsed.get("email"), phone=parsed.get("phone"),
                experience_years=parsed.get("experience_years", 0.0),
                skills=parsed.get("skills", []), education=parsed.get("education", []),
                raw_text=parsed.get("raw_text"),
            )
            db.add(db_obj); db.commit(); db.refresh(db_obj)
            logger.info(f"Resume persisted with id={db_obj.id}")
        except Exception as exc:
            db.rollback()
            logger.warning(f"DB persistence skipped: {exc}")

    return ResumeUploadResponse(success=True, data=ParsedResume(**parsed))
