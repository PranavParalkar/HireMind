"""Curated skill vocabulary for deterministic skill extraction."""

SKILL_ALIASES = {
    "postgres": "postgresql",
    "node.js": "nodejs",
    "node": "nodejs",
    "golang": "go",
    "next.js": "nextjs",
    "nuxt.js": "nextjs",
    "reactjs": "react",
    "react.js": "react",
    "vue.js": "vue",
    "vuejs": "vue",
    "ml": "machine learning",
    "dl": "deep learning",
    "k8s": "kubernetes",
    "tf": "tensorflow",
    "hf": "huggingface",
    "sklearn": "scikit-learn",
}


def canonical(skill: str) -> str:
    """Return canonical form of a skill (apply aliases)."""
    return SKILL_ALIASES.get(skill.lower().strip(), skill.lower().strip())


SKILLS_VOCAB = {
    "python", "java", "javascript", "typescript", "c++", "c#", "golang", "go",
    "rust", "kotlin", "swift", "ruby", "php", "scala", "r", "matlab",
    "react", "angular", "vue", "next.js", "nuxt", "svelte", "redux",
    "html", "css", "sass", "tailwind", "bootstrap",
    "fastapi", "flask", "django", "node.js", "express", "nestjs",
    "spring", "spring boot", "rails", ".net", "graphql", "rest api", "grpc",
    "postgresql", "postgres", "mysql", "mongodb", "redis", "elasticsearch",
    "cassandra", "dynamodb", "sqlite", "oracle", "sql server", "neo4j",
    "aws", "azure", "gcp", "docker", "kubernetes", "terraform", "ansible",
    "jenkins", "github actions", "gitlab ci", "circleci", "helm", "istio",
    "machine learning", "deep learning", "nlp", "computer vision",
    "tensorflow", "pytorch", "keras", "scikit-learn", "pandas", "numpy",
    "spark", "hadoop", "airflow", "dbt", "kafka", "mlflow",
    "sentence transformers", "huggingface", "langchain", "llm", "rag",
    "git", "github", "gitlab", "jira", "agile", "scrum", "kanban",
    "tdd", "ci/cd", "microservices", "distributed systems",
    "leadership", "communication", "teamwork", "problem solving",
}
