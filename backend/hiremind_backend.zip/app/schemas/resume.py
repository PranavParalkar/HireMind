"""Pydantic schemas for resume endpoints."""
from typing import List, Optional
from pydantic import BaseModel, Field


class ParsedResume(BaseModel):
    filename: Optional[str] = None
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    skills: List[str] = Field(default_factory=list)
    experience_years: float = 0.0
    education: List[str] = Field(default_factory=list)
    raw_text: Optional[str] = None


class ResumeUploadResponse(BaseModel):
    success: bool = True
    data: ParsedResume
