"""Smoke tests — run without ML models loaded."""
from app.services.resume_service import ResumeService
from app.services.scoring_service import ScoringService

JD = "We need a Python backend engineer with 3+ years experience using FastAPI, PostgreSQL and Docker."


def test_skill_extraction():
    svc = ResumeService()
    text = "John Doe, Python / FastAPI engineer, 4 years experience. Used PostgreSQL, Docker, AWS."
    skills = svc._extract_skills(text.lower())
    assert "python" in skills
    assert "fastapi" in skills
    assert "postgresql" in skills
    assert "docker" in skills
    assert "aws" in skills


def test_experience_extraction():
    svc = ResumeService()
    assert svc._extract_experience_years("I have 5+ years of experience in Python.") == 5.0
    assert svc._extract_experience_years("8 years of experience") == 8.0


def test_required_experience_parsing():
    assert ScoringService._extract_required_experience(JD) == 3.0


def test_recommendation_buckets():
    assert ScoringService._recommendation(90) == "Strong Fit"
    assert ScoringService._recommendation(60) == "Moderate"
    assert ScoringService._recommendation(10) == "Reject"


def test_skill_aliases():
    from app.utils.skills_db import canonical
    assert canonical("postgres") == "postgresql"
    assert canonical("k8s") == "kubernetes"
    assert canonical("node.js") == "nodejs"
